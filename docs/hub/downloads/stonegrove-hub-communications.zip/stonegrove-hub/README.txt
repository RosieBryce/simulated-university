Stonegrove Hub
==============

This is a snapshot of the Stonegrove Hub, the intranet document estate of
Stonegrove University, taken on 14 April 1053.

Stonegrove University is fictional. Every person, student, applicant,
organisation, case, figure and document in this archive is synthetic. Any
resemblance to a real person or institution is coincidental. The material is
provided so that learners can practise working with institutional documents,
including sensitive-looking ones, with nothing real at risk.

Contents: 29 files in 20 folders, Communications only.

Produced by the Stonegrove University project (RosieBryce/simulated-university).
All rights reserved. The archive may be used for personal learning, teaching
and research. It may not be redistributed or used commercially without
permission. See the LICENSE file in the project repository.

A browsable version, a learner guide and the full Stonegrove dataset are at
the project website.
